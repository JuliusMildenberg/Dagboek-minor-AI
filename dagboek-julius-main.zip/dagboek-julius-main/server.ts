import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize Google GenAI on server
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Endpoint: AI Daily reflection quote
app.get('/api/quote', async (_req, res) => {
  try {
    if (!process.env.GEMINI_API_KEY) {
      const fallbacks = [
        {
          quote: "Wat je vandaag plant, zal morgen bloeien.",
          author: "Oosterse wijsheid",
          theme: "Groei",
        },
        {
          quote: "Geluk zit niet in het bezitten van veel, maar in het genieten van wat er is.",
          author: "Seneca",
          theme: "Dankbaarheid",
        },
        {
          quote: "Neem de tijd om stil te staan; juist dan beweeg je in de juiste richting.",
          author: "Levenswijsheid",
          theme: "Rust",
        },
        {
          quote: "Elke dag is een nieuwe bladzijde in het verhaal van je leven. Schrijf met aandacht.",
          author: "Dagboekwijsheid",
          theme: "Aandacht",
        },
        {
          quote: "Kleine dagelijkse overwinningen vormen samen een betekenisvol leven.",
          author: "Marcus Aurelius",
          theme: "Volharding",
        },
      ];
      const selected = fallbacks[Math.floor(Math.random() * fallbacks.length)];
      return res.json({ ...selected, source: 'curated' });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Genereer één inspirerende, diepzinnige en opbeurende Nederlandstalige spreuk of reflectie voor in een persoonlijk dagboek.
Het moet rustgevend, wijs en bemoedigend zijn (ongeveer 1 à 2 zinnen).
Geef je antwoord uitsluitend als JSON met exact deze velden:
{
  "quote": "De tekst van de spreuk...",
  "author": "De auteur (of bijvoorbeeld 'Levenswijsheid' of 'Boeddhistisch gezegde')",
  "theme": "Eén woord thema zoals 'Dankbaarheid', 'Moed', 'Vertrouwen', 'Rust' of 'Zelfcompassie'"
}`,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text;
    if (text) {
      const parsed = JSON.parse(text);
      return res.json({ ...parsed, source: 'gemini' });
    }

    throw new Error('Geen tekst gegenereerd');
  } catch (error: any) {
    console.error('Fout bij ophalen van AI spreuk:', error);
    res.json({
      quote: "Het mooiste wat je vandaag kunt ontdekken, is vrede in het huidige moment.",
      author: "Levenswijsheid",
      theme: "Aanwezigheid",
      source: 'fallback',
    });
  }
});

async function start() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server gestart op http://0.0.0.0:${port}`);
  });
}

start();
