import { GoogleGenAI } from '@google/genai';

export default async function handler(req: any, res: any) {
  // Support CORS if needed
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const fallbacks = [
    {
      quote: "Wat je vandaag plant, zal morgen bloeien.",
      author: "Oosterse wijsheid",
      theme: "Groei",
    },
    {
      quote: "Geluk zit niet in het bezitten van veel, maar in het genieten van wat er is.",
      author: "Seneca",
      theme: "Dankbaarheid",
    },
    {
      quote: "Neem de tijd om stil te staan; juist dan beweeg je in de juiste richting.",
      author: "Levenswijsheid",
      theme: "Rust",
    },
    {
      quote: "Elke dag is een nieuwe bladzijde in het verhaal van je leven. Schrijf met aandacht.",
      author: "Dagboekwijsheid",
      theme: "Aandacht",
    },
    {
      quote: "Kleine dagelijkse overwinningen vormen samen een betekenisvol leven.",
      author: "Marcus Aurelius",
      theme: "Volharding",
    },
  ];

  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      const selected = fallbacks[Math.floor(Math.random() * fallbacks.length)];
      return res.status(200).json({ ...selected, source: 'curated' });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: { 'User-Agent': 'aistudio-build' },
      },
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Genereer één inspirerende, diepzinnige en opbeurende Nederlandstalige spreuk of reflectie voor in een persoonlijk dagboek.
Het moet rustgevend, wijs en bemoedigend zijn (ongeveer 1 à 2 zinnen).
Geef je antwoord uitsluitend als JSON met exact deze velden:
{
  "quote": "De tekst van de spreuk...",
  "author": "De auteur (of bijvoorbeeld 'Levenswijsheid' of 'Boeddhistisch gezegde')",
  "theme": "Eén woord thema zoals 'Dankbaarheid', 'Moed', 'Vertrouwen', 'Rust' of 'Zelfcompassie'"
}`,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text;
    if (text) {
      const parsed = JSON.parse(text);
      return res.status(200).json({ ...parsed, source: 'gemini' });
    }

    throw new Error('Geen tekst gegenereerd');
  } catch (error: any) {
    const fallback = fallbacks[Math.floor(Math.random() * fallbacks.length)];
    return res.status(200).json({
      ...fallback,
      source: 'fallback',
    });
  }
}
