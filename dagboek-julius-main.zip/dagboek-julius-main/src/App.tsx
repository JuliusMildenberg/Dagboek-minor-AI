import React, { useState, useEffect } from 'react';
import { DiaryEntry, ColorThemeId, COLOR_THEMES } from './types/diary';
import {
  getStoredEntries,
  saveEntry,
  deleteStoredEntry,
  toggleFavoriteEntry,
  getStoredTheme,
  saveStoredTheme,
} from './utils/storage';
import { DiaryForm } from './components/DiaryForm';
import { DiaryList } from './components/DiaryList';
import { DiaryDetailModal } from './components/DiaryDetailModal';
import { BackupView } from './components/BackupView';
import { RequirementsModal } from './components/RequirementsModal';
import { StorageInspectorModal } from './components/StorageInspectorModal';
import { ThemeSelector } from './components/ThemeSelector';
import { PenLine, BookOpen, Database, HelpCircle, HardDrive } from 'lucide-react';

type TabType = 'write' | 'list' | 'backup';

export default function App() {
  const [entries, setEntries] = useState<DiaryEntry[]>([]);
  const [activeTab, setActiveTab] = useState<TabType>('write');
  const [editingEntry, setEditingEntry] = useState<DiaryEntry | null>(null);
  const [viewingEntry, setViewingEntry] = useState<DiaryEntry | null>(null);
  const [isRequirementsOpen, setIsRequirementsOpen] = useState<boolean>(false);
  const [isStorageInspectorOpen, setIsStorageInspectorOpen] = useState<boolean>(false);
  const [currentTheme, setCurrentTheme] = useState<ColorThemeId>('warm-paper');

  // Load entries and theme on mount
  useEffect(() => {
    const loaded = getStoredEntries();
    setEntries(loaded);
    const theme = getStoredTheme();
    setCurrentTheme(theme);
  }, []);

  const refreshEntries = () => {
    const loaded = getStoredEntries();
    setEntries(loaded);
  };

  const handleSelectTheme = (themeId: ColorThemeId) => {
    setCurrentTheme(themeId);
    saveStoredTheme(themeId);
  };

  const handleSaveEntry = (
    entryData: Omit<DiaryEntry, 'id' | 'createdAt'>,
    existingId?: string
  ) => {
    saveEntry(entryData, existingId);
    refreshEntries();
    setEditingEntry(null);
    setActiveTab('list');
  };

  const handleDeleteEntry = (id: string) => {
    deleteStoredEntry(id);
    refreshEntries();
    if (viewingEntry?.id === id) {
      setViewingEntry(null);
    }
  };

  const handleToggleFavorite = (id: string) => {
    const updated = toggleFavoriteEntry(id);
    refreshEntries();
    if (viewingEntry && viewingEntry.id === id && updated) {
      setViewingEntry(updated);
    }
  };

  const handleEditEntry = (entry: DiaryEntry) => {
    setEditingEntry(entry);
    setActiveTab('write');
  };

  const handleNewEntryClick = () => {
    setEditingEntry(null);
    setActiveTab('write');
  };

  // Find active theme config
  const activeThemeObj = COLOR_THEMES.find((t) => t.id === currentTheme) || COLOR_THEMES[0];
  const isDark = currentTheme === 'night';

  return (
    <div className={`min-h-screen flex flex-col ${activeThemeObj.bgClass} ${isDark ? 'text-slate-100' : 'text-stone-900'} pb-20 sm:pb-10 transition-colors duration-200`}>
      {/* Top Bar Header */}
      <header className={`sticky top-0 z-40 ${isDark ? 'bg-slate-900/90 border-slate-800' : 'bg-[#faf9f5]/90 border-stone-200/80'} backdrop-blur-md border-b px-4 sm:px-8 py-3 transition-colors`}>
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
          {/* Brand Wordmark */}
          <button
            onClick={() => {
              setEditingEntry(null);
              setActiveTab('write');
            }}
            className={`text-xl sm:text-2xl font-serif font-semibold tracking-tight ${isDark ? 'text-white hover:text-amber-400' : 'text-stone-900 hover:text-amber-800'} transition-colors cursor-pointer text-left`}
          >
            Digitaal Dagboek
          </button>

          {/* Navigation Links (Desktop) */}
          <nav className={`hidden sm:flex items-center gap-1 ${isDark ? 'bg-slate-800/80' : 'bg-stone-200/60'} p-1 rounded-xl text-xs font-medium`}>
            <button
              onClick={() => {
                setEditingEntry(null);
                setActiveTab('write');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                activeTab === 'write'
                  ? isDark ? 'bg-slate-700 text-white shadow-xs font-semibold' : 'bg-white text-stone-900 shadow-xs font-semibold'
                  : isDark ? 'text-slate-300 hover:text-white' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <PenLine className="w-3.5 h-3.5" />
              <span>{editingEntry ? 'Bewerken' : 'Vandaag schrijven'}</span>
            </button>

            <button
              onClick={() => setActiveTab('list')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                activeTab === 'list'
                  ? isDark ? 'bg-slate-700 text-white shadow-xs font-semibold' : 'bg-white text-stone-900 shadow-xs font-semibold'
                  : isDark ? 'text-slate-300 hover:text-white' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Overzicht ({entries.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('backup')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                activeTab === 'backup'
                  ? isDark ? 'bg-slate-700 text-white shadow-xs font-semibold' : 'bg-white text-stone-900 shadow-xs font-semibold'
                  : isDark ? 'text-slate-300 hover:text-white' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>Back-up</span>
            </button>
          </nav>

          {/* Kleurenthema & Hulpknoppen */}
          <div className="flex items-center gap-2">
            {/* Kleurenthema Kiezer (Punt 1) */}
            <ThemeSelector
              currentTheme={currentTheme}
              onSelectTheme={handleSelectTheme}
            />

            {/* Waar staat mijn data? Knop (Punt 4 & 5) */}
            <button
              onClick={() => setIsStorageInspectorOpen(true)}
              className="hidden lg:flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-stone-700 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors cursor-pointer"
              title="Waar staat mijn data opgeslagen?"
            >
              <HardDrive className="w-3.5 h-3.5 text-stone-500" />
              <span>Opslaginfo</span>
            </button>

            {/* Opdracht Requirements knop */}
            <button
              onClick={() => setIsRequirementsOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-900 bg-amber-100 hover:bg-amber-200 border border-amber-300/80 rounded-xl transition-all cursor-pointer"
              title="Bekijk de details en requirements van Deel 1 & Deel 2"
            >
              <HelpCircle className="w-3.5 h-3.5 text-amber-700" />
              <span className="hidden sm:inline">Opdracht Deel 1 & 2</span>
              <span className="sm:hidden">Info</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-8 py-6 sm:py-8">
        {activeTab === 'write' && (
          <DiaryForm
            initialEntry={editingEntry}
            onSave={handleSaveEntry}
            onCancelEdit={() => {
              setEditingEntry(null);
              setActiveTab('list');
            }}
          />
        )}

        {activeTab === 'list' && (
          <DiaryList
            entries={entries}
            onSelectEntry={(entry) => setViewingEntry(entry)}
            onEditEntry={handleEditEntry}
            onDeleteEntry={handleDeleteEntry}
            onToggleFavorite={handleToggleFavorite}
            onNewEntry={handleNewEntryClick}
          />
        )}

        {activeTab === 'backup' && (
          <BackupView
            entries={entries}
            onRefreshEntries={refreshEntries}
            onOpenStorageInspector={() => setIsStorageInspectorOpen(true)}
          />
        )}
      </main>

      {/* Mobile Bottom Tab Navigation */}
      <nav className={`sm:hidden fixed bottom-0 left-0 right-0 z-40 ${isDark ? 'bg-slate-900/95 border-slate-800' : 'bg-white/95 border-stone-200'} backdrop-blur-md border-t px-2 py-1.5 flex items-center justify-around shadow-lg`}>
        <button
          onClick={() => {
            setEditingEntry(null);
            setActiveTab('write');
          }}
          className={`flex flex-col items-center justify-center min-h-[48px] min-w-[60px] rounded-xl py-1 px-2 transition-colors cursor-pointer ${
            activeTab === 'write'
              ? 'text-amber-600 font-semibold'
              : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <PenLine className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] tracking-tight">Schrijven</span>
        </button>

        <button
          onClick={() => setActiveTab('list')}
          className={`flex flex-col items-center justify-center min-h-[48px] min-w-[60px] rounded-xl py-1 px-2 transition-colors relative cursor-pointer ${
            activeTab === 'list'
              ? 'text-amber-600 font-semibold'
              : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <BookOpen className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] tracking-tight">Dagboek ({entries.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('backup')}
          className={`flex flex-col items-center justify-center min-h-[48px] min-w-[60px] rounded-xl py-1 px-2 transition-colors cursor-pointer ${
            activeTab === 'backup'
              ? 'text-amber-600 font-semibold'
              : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <Database className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] tracking-tight">Back-up</span>
        </button>

        <button
          onClick={() => setIsStorageInspectorOpen(true)}
          className="flex flex-col items-center justify-center min-h-[48px] min-w-[60px] rounded-xl py-1 px-2 text-stone-500 hover:text-amber-600 transition-colors cursor-pointer"
        >
          <HardDrive className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] tracking-tight">Data info</span>
        </button>
      </nav>

      {/* Detail Modal */}
      <DiaryDetailModal
        entry={viewingEntry}
        onClose={() => setViewingEntry(null)}
        onEdit={(entry) => {
          setViewingEntry(null);
          handleEditEntry(entry);
        }}
        onDelete={handleDeleteEntry}
        onToggleFavorite={handleToggleFavorite}
      />

      {/* Storage Inspector Modal (Vragen 4 & 5) */}
      <StorageInspectorModal
        isOpen={isStorageInspectorOpen}
        onClose={() => setIsStorageInspectorOpen(false)}
      />

      {/* Requirements Modal */}
      <RequirementsModal
        isOpen={isRequirementsOpen}
        onClose={() => setIsRequirementsOpen(false)}
        onOpenStorageInspector={() => setIsStorageInspectorOpen(true)}
      />

      {/* Subtle Footer */}
      <footer className={`hidden sm:block border-t ${isDark ? 'border-slate-800 text-slate-400' : 'border-stone-200/60 text-stone-500'} mt-12 py-6 text-center text-xs`}>
        <div className="max-w-4xl mx-auto flex items-center justify-between px-8">
          <p>Digitaal Dagboek · Ondersteund met Google Gemini AI</p>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsStorageInspectorOpen(true)}
              className="hover:underline cursor-pointer"
            >
              Waar staat mijn data?
            </button>
            <span>·</span>
            <button
              onClick={() => setIsRequirementsOpen(true)}
              className="hover:underline cursor-pointer"
            >
              Requirements Deel 1 & 2
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
