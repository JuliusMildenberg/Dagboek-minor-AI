export type MoodType = 'geweldig' | 'goed' | 'neutraal' | 'moeilijk' | 'vermoeid';

export interface MoodOption {
  id: MoodType;
  emoji: string;
  label: string;
}

export interface DiaryEntry {
  id: string;
  date: string; // YYYY-MM-DD
  createdAt: string; // ISO string
  updatedAt?: string;
  mood: MoodType;
  isFavorite?: boolean;
  // De 4 vaste reflectievragen
  question1: string; // Waar ben je vandaag dankbaar voor?
  question2: string; // Wat ging er vandaag goed of wat was je hoogtepunt?
  question3: string; // Wat was een uitdaging of leermoment?
  question4: string; // Wat is je intentie of focus voor morgen?
}

export type ColorThemeId = 'warm-paper' | 'sage' | 'sunset' | 'night' | 'ocean';

export interface ColorTheme {
  id: ColorThemeId;
  name: string;
  description: string;
  bgClass: string;
  accentClass: string;
  cardBorder: string;
  previewColor: string;
}

export const COLOR_THEMES: ColorTheme[] = [
  {
    id: 'warm-paper',
    name: 'Warm Papier & Honing',
    description: 'Klassieke, rustgevende notitieboekstijl met honinggoud.',
    bgClass: 'bg-[#faf9f5]',
    accentClass: 'bg-amber-400 hover:bg-amber-300 text-stone-950',
    cardBorder: 'border-stone-200/80',
    previewColor: '#f59e0b',
  },
  {
    id: 'sage',
    name: 'Saliegroen & Botanisch',
    description: 'Rustgevende natuurtinten met fris bosgroen en salie.',
    bgClass: 'bg-[#f4f7f4]',
    accentClass: 'bg-emerald-600 hover:bg-emerald-500 text-white',
    cardBorder: 'border-emerald-200/70',
    previewColor: '#059669',
  },
  {
    id: 'sunset',
    name: 'Terracotta & Zonsondergang',
    description: 'Warm mediterraan terracotta en zacht perzik.',
    bgClass: 'bg-[#faf6f3]',
    accentClass: 'bg-orange-500 hover:bg-orange-400 text-white',
    cardBorder: 'border-orange-200/80',
    previewColor: '#f97316',
  },
  {
    id: 'night',
    name: 'Schemering & Nachtblauw',
    description: 'Elegante donkere avondmodus met diepblauw en goud.',
    bgClass: 'bg-[#0f172a]',
    accentClass: 'bg-amber-400 hover:bg-amber-300 text-stone-950',
    cardBorder: 'border-slate-800',
    previewColor: '#38bdf8',
  },
  {
    id: 'ocean',
    name: 'Oceaan & Kust',
    description: 'Heldere, kalmerende zeeblauwe tinten.',
    bgClass: 'bg-[#f0f7f9]',
    accentClass: 'bg-teal-600 hover:bg-teal-500 text-white',
    cardBorder: 'border-teal-200/80',
    previewColor: '#0d9488',
  },
];

export const MOODS: MoodOption[] = [
  { id: 'geweldig', emoji: '🌟', label: 'Geweldig' },
  { id: 'goed', emoji: '😊', label: 'Goed' },
  { id: 'neutraal', emoji: '😐', label: 'Neutraal' },
  { id: 'moeilijk', emoji: '🌧️', label: 'Moeilijk' },
  { id: 'vermoeid', emoji: '🥱', label: 'Moe' },
];

export const DIARY_QUESTIONS = [
  {
    id: 'question1',
    number: 1,
    title: 'Waar ben je vandaag dankbaar voor?',
    subtitle: 'Noem 1 tot 3 dingen, groot of klein.',
    placeholder: 'Bijvoorbeeld: een lekkere kop koffie in de zon, een fijn gesprek met een vriend...',
  },
  {
    id: 'question2',
    number: 2,
    title: 'Wat ging er vandaag goed of wat was je hoogtepunt?',
    subtitle: 'Een succes, een fijn moment of iets waar je trots op bent.',
    placeholder: 'Bijvoorbeeld: een taak afgerond waar ik tegenop zag, lekker gesport...',
  },
  {
    id: 'question3',
    number: 3,
    title: 'Wat was een uitdaging of leermoment?',
    subtitle: 'Iets wat lastig was en wat je daarvan hebt meegenomen.',
    placeholder: 'Bijvoorbeeld: ik liet me even afleiden, maar herpakte me daarna goed...',
  },
  {
    id: 'question4',
    number: 4,
    title: 'Wat is je intentie of focus voor morgen?',
    subtitle: 'Waar wil je morgen je aandacht of energie aan geven?',
    placeholder: 'Bijvoorbeeld: op tijd naar bed, met rust aan het project beginnen...',
  },
] as const;

export interface DailyQuote {
  quote: string;
  author: string;
  theme?: string;
  source?: string;
}
