import React from 'react';
import { DiaryEntry, MOODS, DIARY_QUESTIONS } from '../types/diary';
import { formatDateDutch } from '../utils/storage';
import { X, Edit3, Trash2, Calendar, Printer, Heart, Star } from 'lucide-react';

interface DiaryDetailModalProps {
  entry: DiaryEntry | null;
  onClose: () => void;
  onEdit: (entry: DiaryEntry) => void;
  onDelete: (id: string) => void;
  onToggleFavorite?: (id: string) => void;
}

export const DiaryDetailModal: React.FC<DiaryDetailModalProps> = ({
  entry,
  onClose,
  onEdit,
  onDelete,
  onToggleFavorite,
}) => {
  if (!entry) return null;

  const currentMood = MOODS.find((m) => m.id === entry.mood) || MOODS[1];

  const handlePrint = () => {
    window.print();
  };

  const handleDelete = () => {
    if (window.confirm('Weet je zeker dat je deze dagboeknotitie wilt verwijderen?')) {
      onDelete(entry.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl bg-[#faf9f5] border border-stone-200 rounded-3xl shadow-xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-white">
          <div className="flex items-center gap-2 text-stone-700 text-sm flex-wrap">
            <Calendar className="w-4 h-4 text-stone-500" />
            <span className="font-semibold capitalize">
              {formatDateDutch(entry.date)}
            </span>
            <span className="text-stone-300">·</span>
            <span className="flex items-center gap-1 bg-stone-100 px-2 py-0.5 rounded-full text-xs font-medium">
              <span>{currentMood.emoji}</span>
              <span>{currentMood.label}</span>
            </span>
          </div>

          <div className="flex items-center gap-1">
            {onToggleFavorite && (
              <button
                onClick={() => onToggleFavorite(entry.id)}
                title={entry.isFavorite ? 'Verwijder uit favorieten' : 'Markeer als favoriet'}
                className={`p-2 rounded-lg transition-colors cursor-pointer ${
                  entry.isFavorite
                    ? 'text-amber-500 bg-amber-50 hover:bg-amber-100'
                    : 'text-stone-400 hover:text-amber-500 hover:bg-stone-100'
                }`}
              >
                <Star className={`w-4 h-4 ${entry.isFavorite ? 'fill-amber-500' : ''}`} />
              </button>
            )}
            <button
              onClick={handlePrint}
              title="Afdrukken of opslaan als PDF"
              className="p-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-lg transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                onClose();
                onEdit(entry);
              }}
              title="Notitie bewerken"
              className="p-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-lg transition-colors cursor-pointer"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            <button
              onClick={handleDelete}
              title="Verwijderen"
              className="p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              title="Sluiten"
              className="p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-lg transition-colors ml-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          <div className="border-b border-stone-200/80 pb-4 flex items-center justify-between">
            <div>
              <span className="text-xs uppercase tracking-wider text-amber-700 font-semibold flex items-center gap-1">
                <Heart className="w-3.5 h-3.5 text-amber-500" />
                Dagboekinzending
              </span>
              <h2 className="text-2xl sm:text-3xl font-serif text-stone-900 mt-1 capitalize">
                {formatDateDutch(entry.date)}
              </h2>
            </div>
            {entry.isFavorite && (
              <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-900 px-2.5 py-1 rounded-full text-xs font-semibold">
                <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                Favoriete dag
              </span>
            )}
          </div>

          <div className="space-y-6">
            {DIARY_QUESTIONS.map((q) => {
              let answer = '';
              if (q.number === 1) answer = entry.question1;
              if (q.number === 2) answer = entry.question2;
              if (q.number === 3) answer = entry.question3;
              if (q.number === 4) answer = entry.question4;

              return (
                <div key={q.id} className="bg-white rounded-2xl p-5 border border-stone-200/80 shadow-xs">
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full">
                      Vraag {q.number}
                    </span>
                    <h3 className="text-sm font-semibold text-stone-800">
                      {q.title}
                    </h3>
                  </div>

                  <div className="mt-2 text-stone-700 text-sm leading-relaxed whitespace-pre-wrap pl-2 border-l-2 border-amber-200">
                    {answer ? answer : <span className="italic text-stone-400">Geen antwoord ingevuld.</span>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-stone-100/70 border-t border-stone-200 flex items-center justify-between text-xs text-stone-500">
          <span>Gemaakt op {new Date(entry.createdAt).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })}</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors cursor-pointer"
          >
            Sluiten
          </button>
        </div>
      </div>
    </div>
  );
};
