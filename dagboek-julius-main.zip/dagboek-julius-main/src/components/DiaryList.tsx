import React, { useState, useMemo } from 'react';
import { DiaryEntry, MoodType, MOODS } from '../types/diary';
import { formatDateDutch, exportEntriesAsExcelCsv } from '../utils/storage';
import { Search, Calendar, Edit3, Trash2, ChevronRight, BookOpen, Sparkles, Star, FileSpreadsheet, Flame } from 'lucide-react';

interface DiaryListProps {
  entries: DiaryEntry[];
  onSelectEntry: (entry: DiaryEntry) => void;
  onEditEntry: (entry: DiaryEntry) => void;
  onDeleteEntry: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onNewEntry: () => void;
}

export const DiaryList: React.FC<DiaryListProps> = ({
  entries,
  onSelectEntry,
  onEditEntry,
  onDeleteEntry,
  onToggleFavorite,
  onNewEntry,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMoodFilter, setSelectedMoodFilter] = useState<MoodType | 'all'>('all');
  const [onlyFavorites, setOnlyFavorites] = useState<boolean>(false);

  // Calculate writing streak
  const streak = useMemo(() => {
    if (entries.length === 0) return 0;
    const sortedDates = Array.from(new Set(entries.map((e) => e.date))).sort().reverse();
    return sortedDates.length;
  }, [entries]);

  const filteredEntries = useMemo(() => {
    return entries.filter((entry) => {
      // Favorite filter
      if (onlyFavorites && !entry.isFavorite) {
        return false;
      }
      // Mood filter
      if (selectedMoodFilter !== 'all' && entry.mood !== selectedMoodFilter) {
        return false;
      }
      // Search text
      if (searchTerm.trim() !== '') {
        const term = searchTerm.toLowerCase();
        const dateMatch = formatDateDutch(entry.date).toLowerCase().includes(term);
        const q1Match = entry.question1.toLowerCase().includes(term);
        const q2Match = entry.question2.toLowerCase().includes(term);
        const q3Match = entry.question3.toLowerCase().includes(term);
        const q4Match = entry.question4.toLowerCase().includes(term);
        return dateMatch || q1Match || q2Match || q3Match || q4Match;
      }
      return true;
    });
  }, [entries, selectedMoodFilter, onlyFavorites, searchTerm]);

  return (
    <div className="w-full max-w-3xl mx-auto space-y-5">
      {/* Title + Action & Excel Export */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl sm:text-3xl font-serif text-stone-900 tracking-tight">
              Mijn Dagboek
            </h2>
            {streak > 0 && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-orange-100 border border-orange-200 text-orange-800 text-xs font-semibold">
                <Flame className="w-3.5 h-3.5 fill-orange-500 text-orange-500" />
                <span>{streak} {streak === 1 ? 'dag' : 'dagen'} gereflecteerd</span>
              </span>
            )}
          </div>
          <p className="text-sm text-stone-600 mt-0.5">
            {entries.length === 1 ? '1 opgeslagen dag' : `${entries.length} opgeslagen dagen`}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Requirement 6: Download button naar Excel */}
          <button
            onClick={exportEntriesAsExcelCsv}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-900 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 rounded-xl transition-all cursor-pointer shadow-2xs"
            title="Download alle dagboeknotities direct als Excel-spreadsheet (.csv)"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
            <span>Excel download</span>
          </button>

          <button
            onClick={onNewEntry}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-stone-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Vandaag schrijven
          </button>
        </div>
      </div>

      {/* Zoekbalk, Favorieten filter & Mood filter */}
      <div className="bg-white border border-stone-200/80 rounded-2xl p-4 shadow-xs space-y-3">
        {/* Zoeken & Favorieten filter */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Zoek in dagboeknotities (bv. dankbaar, werk, zon)..."
              className="w-full pl-9 pr-3 py-2 text-sm bg-stone-50 border border-stone-200 rounded-xl text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-400/20 focus:border-amber-400"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-600 cursor-pointer"
              >
                Wissen
              </button>
            )}
          </div>

          <button
            onClick={() => setOnlyFavorites(!onlyFavorites)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium border transition-colors cursor-pointer shrink-0 ${
              onlyFavorites
                ? 'bg-amber-100 border-amber-300 text-amber-900 font-semibold'
                : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
            }`}
            title="Alleen favoriete dagen tonen"
          >
            <Star className={`w-3.5 h-3.5 ${onlyFavorites ? 'fill-amber-500 text-amber-500' : 'text-stone-400'}`} />
            <span>Favorieten</span>
          </button>
        </div>

        {/* Stemming filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-stone-400 mr-1 text-[11px] font-medium uppercase tracking-wider shrink-0">
            Stemming:
          </span>
          <button
            onClick={() => setSelectedMoodFilter('all')}
            className={`px-3 py-1 rounded-lg transition-colors shrink-0 font-medium cursor-pointer ${
              selectedMoodFilter === 'all'
                ? 'bg-stone-900 text-white'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            Alle ({entries.length})
          </button>
          {MOODS.map((m) => {
            const count = entries.filter((e) => e.mood === m.id).length;
            const isSelected = selectedMoodFilter === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setSelectedMoodFilter(m.id)}
                className={`px-2.5 py-1 rounded-lg transition-colors shrink-0 flex items-center gap-1 font-medium cursor-pointer ${
                  isSelected
                    ? 'bg-amber-300 text-stone-900 ring-1 ring-amber-400'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                <span>{m.emoji}</span>
                <span>{m.label}</span>
                <span className="text-[10px] text-stone-400">({count})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Entry List */}
      {filteredEntries.length === 0 ? (
        <div className="bg-white border border-dashed border-stone-300 rounded-3xl p-10 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto">
            <BookOpen className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-stone-800">
            {searchTerm || selectedMoodFilter !== 'all' || onlyFavorites
              ? 'Geen dagboeknotities gevonden met deze filters'
              : 'Nog geen dagboeknotities'}
          </h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            {searchTerm || selectedMoodFilter !== 'all' || onlyFavorites
              ? 'Probeer een ander zoekwoord of reset de filters om al je notities te zien.'
              : 'Begin vandaag met je eerste reflectie in 4 eenvoudige vragen.'}
          </p>
          {(searchTerm || selectedMoodFilter !== 'all' || onlyFavorites) ? (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedMoodFilter('all');
                setOnlyFavorites(false);
              }}
              className="text-xs text-amber-700 font-semibold underline hover:text-amber-800 cursor-pointer"
            >
              Filters wissen
            </button>
          ) : (
            <button
              onClick={onNewEntry}
              className="mt-2 inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-stone-950 bg-amber-400 hover:bg-amber-300 rounded-xl cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Eerste dag schrijven
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {filteredEntries.map((entry) => {
            const moodObj = MOODS.find((m) => m.id === entry.mood) || MOODS[1];
            return (
              <div
                key={entry.id}
                className="group bg-white border border-stone-200/80 hover:border-amber-400/80 rounded-2xl p-4 sm:p-5 shadow-xs hover:shadow-sm transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer"
                onClick={() => onSelectEntry(entry)}
              >
                {/* Info & Content Snippet */}
                <div className="space-y-2 flex-1 min-w-0">
                  {/* Top Bar: Date, Mood & Star */}
                  <div className="flex items-center gap-2 text-xs text-stone-500">
                    <span className="flex items-center gap-1.5 font-semibold text-stone-800 capitalize">
                      <Calendar className="w-3.5 h-3.5 text-stone-400" />
                      {formatDateDutch(entry.date)}
                    </span>
                    <span>·</span>
                    <span className="inline-flex items-center gap-1 bg-stone-100 px-2 py-0.5 rounded-full text-stone-700 font-medium">
                      <span>{moodObj.emoji}</span>
                      <span>{moodObj.label}</span>
                    </span>
                    {entry.isFavorite && (
                      <span className="inline-flex items-center gap-0.5 text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded text-[11px] font-medium">
                        <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                        <span>Favoriet</span>
                      </span>
                    )}
                  </div>

                  {/* Highlights */}
                  <div className="space-y-1">
                    {entry.question1 && (
                      <p className="text-sm text-stone-800 line-clamp-1">
                        <span className="font-semibold text-stone-600">Dankbaar: </span>
                        {entry.question1}
                      </p>
                    )}
                    {entry.question2 && (
                      <p className="text-xs text-stone-600 line-clamp-1">
                        <span className="font-semibold text-stone-500">Hoogtepunt: </span>
                        {entry.question2}
                      </p>
                    )}
                  </div>
                </div>

                {/* Right side controls */}
                <div
                  className="flex items-center gap-1 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-stone-100 justify-end"
                  onClick={(e) => e.stopPropagation()}
                >
                  <button
                    onClick={() => onToggleFavorite(entry.id)}
                    title={entry.isFavorite ? 'Verwijder uit favorieten' : 'Markeer als favoriet'}
                    className={`p-2 rounded-lg transition-colors cursor-pointer ${
                      entry.isFavorite
                        ? 'text-amber-500 bg-amber-50 hover:bg-amber-100'
                        : 'text-stone-400 hover:text-amber-500 hover:bg-stone-100'
                    }`}
                  >
                    <Star className={`w-4 h-4 ${entry.isFavorite ? 'fill-amber-500' : ''}`} />
                  </button>
                  <button
                    onClick={() => onEditEntry(entry)}
                    title="Bewerken"
                    className="p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-lg transition-colors cursor-pointer"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      if (window.confirm('Weet je zeker dat je deze notitie wilt verwijderen?')) {
                        onDeleteEntry(entry.id);
                      }
                    }}
                    title="Verwijderen"
                    className="p-2 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onSelectEntry(entry)}
                    className="p-2 text-stone-400 group-hover:text-amber-600 group-hover:translate-x-0.5 transition-all cursor-pointer"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
