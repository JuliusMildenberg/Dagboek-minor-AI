import React from 'react';
import { X, CheckCircle2, Smartphone, HelpCircle, Sparkles, HardDrive, FileSpreadsheet, Palette } from 'lucide-react';
import { DIARY_QUESTIONS } from '../types/diary';

interface RequirementsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenStorageInspector: () => void;
}

export const RequirementsModal: React.FC<RequirementsModalProps> = ({
  isOpen,
  onClose,
  onOpenStorageInspector,
}) => {
  if (!isOpen) return null;

  const currentUrl = window.location.href;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl bg-white border border-stone-200 rounded-3xl shadow-xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-amber-50/50">
          <div className="flex items-center gap-2 text-stone-900">
            <HelpCircle className="w-5 h-5 text-amber-600" />
            <h2 className="font-serif text-lg font-bold">
              Opdrachtoverzicht · Deel 1 & Deel 2
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-white rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-stone-800 text-sm">
          {/* Deel 2: De 6 Nieuwe Punten */}
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-300 space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-700" />
              <h3 className="font-serif font-bold text-amber-950 text-base">
                Deel 2: De 6 Uitbreidingen & Antwoorden
              </h3>
            </div>

            <div className="space-y-2 text-xs text-stone-700">
              <div className="p-2.5 bg-white rounded-xl border border-amber-200 flex items-start gap-2">
                <Palette className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong>1. Kleuren wijzigen:</strong> Thema-kiezer rechtsboven toegevoegd met 5 rustgevende kleurpaletten (Warm Papier, Saliegroen, Terracotta, Nachtblauw en Oceaan).
                </div>
              </div>

              <div className="p-2.5 bg-white rounded-xl border border-amber-200 flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong>2. AI Spreuk van de dag:</strong> Elke dag een inspirerende spreuk via Google Gemini AI (`gemini-3.8-flash`), inclusief knop om direct een nieuwe spreuk op te roepen!
                </div>
              </div>

              <div className="p-2.5 bg-white rounded-xl border border-amber-200 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <strong>3. Extra requirements toegevoegd:</strong> Favorieten ⭐ markeren en filteren, automatische schrijfstreak-teller 🔥, en Excel data-export.
                </div>
              </div>

              <div className="p-2.5 bg-white rounded-xl border border-amber-200 flex items-start gap-2">
                <HardDrive className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <strong>4 & 5. Waar staat de data & voor-/nadelen:</strong> Opgeslagen in browser <code className="bg-stone-100 px-1 font-mono">localStorage</code>.
                  <div className="mt-1">
                    <button
                      onClick={() => {
                        onClose();
                        onOpenStorageInspector();
                      }}
                      className="text-amber-800 font-semibold underline hover:text-amber-900 cursor-pointer"
                    >
                      Open het interactieve data-inspectiepaneel &raquo;
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-2.5 bg-white rounded-xl border border-amber-200 flex items-start gap-2">
                <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <strong>6. Excel downloadknop:</strong> Directe downloadknop naar Microsoft Excel (.csv met alle kolommen en UTF-8 BOM) in zowel het Overzicht als Back-up tabblad.
                </div>
              </div>
            </div>
          </div>

          {/* Deel 1: 5 User Stories */}
          <div className="space-y-3">
            <h3 className="text-xs uppercase tracking-wider font-bold text-stone-500">
              Deel 1 · De 5 Oorspronkelijke User Stories
            </h3>

            <div className="space-y-2">
              <div className="p-2.5 rounded-xl border border-stone-200 bg-stone-50 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-stone-900">US 1 · Reflectie:</span> Datum, stemming en de 4 vaste vragen invullen.
                </div>
              </div>

              <div className="p-2.5 rounded-xl border border-stone-200 bg-stone-50 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-stone-900">US 2 · Direct lokaal bewaren:</span> Zonder account of server direct veilig opgeslagen in LocalStorage.
                </div>
              </div>

              <div className="p-2.5 rounded-xl border border-stone-200 bg-stone-50 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-stone-900">US 3 · Overzicht & zoeken:</span> Tijdlijn doorzoeken op trefwoord en filteren op stemming.
                </div>
              </div>

              <div className="p-2.5 rounded-xl border border-stone-200 bg-stone-50 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-stone-900">US 4 · Teruglezen & bewerken:</span> Details rustig inzien en achteraf bewerken.
                </div>
              </div>

              <div className="p-2.5 rounded-xl border border-stone-200 bg-stone-50 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-stone-900">US 5 · Verwijderen & Exporteren:</span> Verwijderen en export naar JSON en Excel.
                </div>
              </div>
            </div>
          </div>

          {/* De 4 Vragen */}
          <div className="space-y-2 pt-2 border-t border-stone-200">
            <h3 className="text-xs uppercase tracking-wider font-bold text-stone-500">
              De 4 Dagelijkse Reflectievragen
            </h3>
            <ol className="list-decimal list-inside space-y-1 text-xs text-stone-700 bg-stone-50 p-3 rounded-xl border border-stone-200">
              {DIARY_QUESTIONS.map((q) => (
                <li key={q.id} className="py-0.5">
                  <span className="font-medium text-stone-900">{q.title}</span>
                </li>
              ))}
            </ol>
          </div>

          {/* Mobiel testen */}
          <div className="p-3.5 rounded-2xl bg-stone-100 border border-stone-200 space-y-1.5 text-xs text-stone-700">
            <div className="flex items-center gap-1.5 font-semibold text-stone-900">
              <Smartphone className="w-4 h-4 text-stone-600" />
              <span>Testen op mobiele telefoon</span>
            </div>
            <p className="text-stone-600">
              Open de Shared App link op je telefoon om de speciale duimnavigatie en touch interface te testen.
            </p>
            <div className="font-mono text-[11px] bg-white p-2 rounded-lg border border-stone-300 break-all select-all">
              {currentUrl}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-stone-50 border-t border-stone-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-900 bg-amber-400 hover:bg-amber-300 rounded-xl transition-colors cursor-pointer"
          >
            Sluiten
          </button>
        </div>
      </div>
    </div>
  );
};
