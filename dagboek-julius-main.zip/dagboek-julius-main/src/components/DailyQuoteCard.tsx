import React, { useState, useEffect } from 'react';
import { DailyQuote } from '../types/diary';
import { Sparkles, RotateCw, Quote, Check, Copy } from 'lucide-react';

interface DailyQuoteCardProps {
  onInsertQuote?: (quoteText: string) => void;
}

export const DailyQuoteCard: React.FC<DailyQuoteCardProps> = ({ onInsertQuote }) => {
  const [quote, setQuote] = useState<DailyQuote | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchQuote = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/quote');
      if (!res.ok) {
        throw new Error(`Server status ${res.status}`);
      }
      const data: DailyQuote = await res.json();
      setQuote(data);
    } catch (err: any) {
      console.error('Fout bij ophalen spreuk:', err);
      // Fallback
      setQuote({
        quote: "Wat je vandaag plant, zal morgen bloeien. Neem rust en schrijf met aandacht.",
        author: "Levenswijsheid",
        theme: "Aandacht",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchQuote();
  }, []);

  const handleCopy = () => {
    if (!quote) return;
    navigator.clipboard.writeText(`"${quote.quote}" — ${quote.author}`);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-amber-500/10 via-amber-100/40 to-orange-100/20 border border-amber-300/80 rounded-3xl p-5 sm:p-6 shadow-xs transition-all mb-6">
      {/* Decorative quotes background */}
      <Quote className="absolute -right-4 -bottom-4 w-28 h-28 text-amber-500/10 pointer-events-none -rotate-12" />

      <div className="relative z-10 space-y-3">
        {/* Badge & Model label */}
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-900 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
            <span>Spreuk van de dag · Gegenereerd door Google Gemini AI</span>
          </div>

          {quote?.theme && (
            <span className="text-[11px] font-medium tracking-wide uppercase px-2 py-0.5 rounded-md bg-stone-200/50 text-stone-600">
              #{quote.theme}
            </span>
          )}
        </div>

        {/* The Quote */}
        <div className="min-h-[64px] flex items-center py-1">
          {isLoading ? (
            <div className="flex items-center gap-2.5 text-stone-500 text-sm py-3">
              <RotateCw className="w-4 h-4 animate-spin text-amber-600" />
              <span>Google AI bedenkt een nieuwe inspirerende spreuk voor je...</span>
            </div>
          ) : (
            <blockquote className="space-y-1.5">
              <p className="font-serif italic text-base sm:text-lg text-stone-800 leading-snug">
                &ldquo;{quote?.quote || 'Neem een moment van rust en sta stil bij je dag.'}&rdquo;
              </p>
              <footer className="text-xs font-medium text-stone-500 flex items-center gap-1">
                <span>— {quote?.author || 'Levenswijsheid'}</span>
              </footer>
            </blockquote>
          )}
        </div>

        {/* Action Buttons: New Quote & Copy/Use */}
        <div className="pt-2 border-t border-amber-200/60 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={fetchQuote}
              disabled={isLoading}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white hover:bg-stone-50 border border-stone-300 text-stone-800 text-xs font-medium shadow-2xs hover:shadow-xs transition-all cursor-pointer disabled:opacity-50"
              title="Vraag Google AI om een andere spreuk als deze je niet aanspreekt"
            >
              <RotateCw className={`w-3.5 h-3.5 text-amber-600 ${isLoading ? 'animate-spin' : ''}`} />
              <span>Nieuwe spreuk oproepen</span>
            </button>

            {onInsertQuote && quote?.quote && (
              <button
                type="button"
                onClick={() => onInsertQuote(`"${quote.quote}" — ${quote.author}`)}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-200/60 hover:bg-amber-200 text-stone-800 text-xs font-medium transition-colors cursor-pointer"
                title="Gebruik deze spreuk als inspiratie in je reflectie"
              >
                <span>Gebruik in dagboek</span>
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-1 text-xs text-stone-500 hover:text-stone-800 transition-colors py-1 px-2 rounded-lg hover:bg-white/60"
            title="Kopieer spreuk naar klembord"
          >
            {isCopied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-700 font-medium">Gekopieerd!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-stone-400" />
                <span>Kopiëren</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
