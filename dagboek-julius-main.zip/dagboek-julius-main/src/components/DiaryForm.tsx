import React, { useState, useEffect } from 'react';
import { DiaryEntry, MoodType, MOODS, DIARY_QUESTIONS } from '../types/diary';
import { getTodayString, formatDateDutch } from '../utils/storage';
import { DailyQuoteCard } from './DailyQuoteCard';
import { Calendar, Smile, Check, Sparkles, AlertCircle, Star } from 'lucide-react';

interface DiaryFormProps {
  initialEntry?: DiaryEntry | null;
  onSave: (entry: Omit<DiaryEntry, 'id' | 'createdAt'>, existingId?: string) => void;
  onCancelEdit?: () => void;
}

export const DiaryForm: React.FC<DiaryFormProps> = ({
  initialEntry,
  onSave,
  onCancelEdit,
}) => {
  const [date, setDate] = useState<string>(initialEntry ? initialEntry.date : getTodayString());
  const [mood, setMood] = useState<MoodType>(initialEntry ? initialEntry.mood : 'goed');
  const [isFavorite, setIsFavorite] = useState<boolean>(initialEntry?.isFavorite || false);
  const [q1, setQ1] = useState<string>(initialEntry ? initialEntry.question1 : '');
  const [q2, setQ2] = useState<string>(initialEntry ? initialEntry.question2 : '');
  const [q3, setQ3] = useState<string>(initialEntry ? initialEntry.question3 : '');
  const [q4, setQ4] = useState<string>(initialEntry ? initialEntry.question4 : '');
  const [showSavedNotification, setShowSavedNotification] = useState<boolean>(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  useEffect(() => {
    if (initialEntry) {
      setDate(initialEntry.date);
      setMood(initialEntry.mood);
      setIsFavorite(initialEntry.isFavorite || false);
      setQ1(initialEntry.question1);
      setQ2(initialEntry.question2);
      setQ3(initialEntry.question3);
      setQ4(initialEntry.question4);
    }
  }, [initialEntry]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Check if at least one question has an answer
    if (!q1.trim() && !q2.trim() && !q3.trim() && !q4.trim()) {
      setValidationError('Beantwoord ten minste één van de 4 vragen om je dagboeknotitie op te slaan.');
      return;
    }

    setValidationError(null);

    onSave(
      {
        date,
        mood,
        isFavorite,
        question1: q1.trim(),
        question2: q2.trim(),
        question3: q3.trim(),
        question4: q4.trim(),
      },
      initialEntry?.id
    );

    setShowSavedNotification(true);
    setTimeout(() => {
      setShowSavedNotification(false);
    }, 2800);

    if (!initialEntry) {
      // Clear form after new entry
      setQ1('');
      setQ2('');
      setQ3('');
      setQ4('');
      setIsFavorite(false);
    }
  };

  const getQuestionValue = (num: number) => {
    switch (num) {
      case 1: return q1;
      case 2: return q2;
      case 3: return q3;
      case 4: return q4;
      default: return '';
    }
  };

  const setQuestionValue = (num: number, val: string) => {
    switch (num) {
      case 1: setQ1(val); break;
      case 2: setQ2(val); break;
      case 3: setQ3(val); break;
      case 4: setQ4(val); break;
    }
    if (validationError) setValidationError(null);
  };

  const handleInsertQuote = (quoteText: string) => {
    // Inserts the quote into question 1 or question 4
    if (!q1) {
      setQ1(`Inspirerende spreuk: ${quoteText}`);
    } else {
      setQ4((prev) => (prev ? `${prev}\n\nInspiratie: ${quoteText}` : `Inspiratie: ${quoteText}`));
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      {/* Header */}
      <div className="mb-5">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <h2 className="text-2xl sm:text-3xl font-serif text-stone-900 tracking-tight">
              {initialEntry ? 'Dagboeknotitie bewerken' : 'Dagelijkse reflectie'}
            </h2>
            <p className="text-sm text-stone-600 mt-1">
              Neem een paar minuten rust om je dag in 4 eenvoudige vragen vast te leggen.
            </p>
          </div>
          {initialEntry && onCancelEdit && (
            <button
              type="button"
              onClick={onCancelEdit}
              className="text-xs text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
            >
              Annuleren
            </button>
          )}
        </div>
      </div>

      {/* Punt 2: Spreuk van de dag gegenereerd door Google Gemini AI met button voor nieuwe spreuk */}
      <DailyQuoteCard onInsertQuote={handleInsertQuote} />

      {showSavedNotification && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3 animate-in fade-in duration-200">
          <Check className="w-5 h-5 text-emerald-600 shrink-0" />
          <p className="text-sm font-medium">
            Je dagboeknotitie is veilig opgeslagen in je lokale geheugen!
          </p>
        </div>
      )}

      {validationError && (
        <div className="mb-6 p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
          <p className="text-sm">{validationError}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Datum & Stemming bar */}
        <div className="bg-white border border-stone-200/80 rounded-2xl p-4 sm:p-5 shadow-xs space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Datum */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="flex items-center gap-1.5 text-xs font-semibold text-stone-700 uppercase tracking-wider">
                  <Calendar className="w-3.5 h-3.5 text-stone-500" />
                  Datum
                </label>
                <button
                  type="button"
                  onClick={() => setIsFavorite(!isFavorite)}
                  className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                    isFavorite
                      ? 'bg-amber-100 text-amber-900 font-semibold'
                      : 'text-stone-400 hover:text-stone-700'
                  }`}
                  title="Markeer als favoriete dag"
                >
                  <Star className={`w-3.5 h-3.5 ${isFavorite ? 'fill-amber-500 text-amber-500' : ''}`} />
                  <span>{isFavorite ? 'Favoriet' : 'Markeer favoriet'}</span>
                </button>
              </div>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2.5 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition-all"
                required
              />
              <p className="text-xs text-stone-500 mt-1 capitalize">
                {formatDateDutch(date)}
              </p>
            </div>

            {/* Stemming keuze */}
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1.5">
                <Smile className="w-3.5 h-3.5 text-stone-500" />
                Hoe voel je je vandaag?
              </label>
              <div className="grid grid-cols-5 gap-1 sm:gap-2">
                {MOODS.map((m) => {
                  const isSelected = mood === m.id;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setMood(m.id)}
                      className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all border text-center cursor-pointer ${
                        isSelected
                          ? 'bg-amber-50 border-amber-400 text-stone-900 shadow-xs ring-1 ring-amber-400'
                          : 'bg-stone-50/70 border-stone-200 text-stone-600 hover:bg-stone-100 hover:border-stone-300'
                      }`}
                    >
                      <span className="text-xl sm:text-2xl leading-none mb-1">{m.emoji}</span>
                      <span className="text-[11px] font-medium leading-tight truncate w-full">
                        {m.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* De 4 Vaste Reflectievragen */}
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-stone-500 px-1">
            <span className="font-semibold uppercase tracking-wider text-stone-600">
              De 4 reflectievragen
            </span>
            <span>Vast format voor rust & overzicht</span>
          </div>

          {DIARY_QUESTIONS.map((q) => {
            const val = getQuestionValue(q.number);
            return (
              <div
                key={q.id}
                className="bg-white border border-stone-200/80 rounded-2xl p-4 sm:p-5 shadow-xs transition-all focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/20"
              >
                <div className="flex items-start gap-3 mb-2">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-amber-100 text-amber-900 text-xs font-bold shrink-0 mt-0.5">
                    {q.number}
                  </span>
                  <div className="flex-1">
                    <h3 className="text-base font-semibold text-stone-900">
                      {q.title}
                    </h3>
                    <p className="text-xs text-stone-500 mt-0.5">
                      {q.subtitle}
                    </p>
                  </div>
                </div>

                <textarea
                  rows={3}
                  value={val}
                  onChange={(e) => setQuestionValue(q.number, e.target.value)}
                  placeholder={q.placeholder}
                  className="w-full mt-2 bg-stone-50/50 hover:bg-stone-50 border border-stone-200/80 rounded-xl p-3 text-sm text-stone-800 placeholder-stone-400 focus:bg-white focus:outline-none focus:border-amber-400 transition-all resize-y min-h-[72px]"
                />
              </div>
            );
          })}
        </div>

        {/* Actions */}
        <div className="pt-2 pb-6 flex items-center justify-between gap-3">
          <div className="text-xs text-stone-500">
            <span>Gegevens blijven lokaal in je browser bewaard.</span>
          </div>

          <div className="flex items-center gap-2">
            {initialEntry && onCancelEdit && (
              <button
                type="button"
                onClick={onCancelEdit}
                className="px-4 py-2.5 text-sm font-medium text-stone-700 bg-white border border-stone-200 rounded-xl hover:bg-stone-50 transition-colors cursor-pointer"
              >
                Annuleren
              </button>
            )}

            <button
              type="submit"
              className="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-stone-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-xl shadow-xs transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-stone-900" />
              {initialEntry ? 'Wijzigingen opslaan' : 'Dagboek opslaan'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
