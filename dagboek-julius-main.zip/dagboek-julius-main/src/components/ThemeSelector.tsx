import React from 'react';
import { ColorThemeId, COLOR_THEMES } from '../types/diary';
import { Palette, Check } from 'lucide-react';

interface ThemeSelectorProps {
  currentTheme: ColorThemeId;
  onSelectTheme: (themeId: ColorThemeId) => void;
}

export const ThemeSelector: React.FC<ThemeSelectorProps> = ({ currentTheme, onSelectTheme }) => {
  return (
    <div className="flex items-center gap-1 bg-stone-100/80 p-1 rounded-xl border border-stone-200/80">
      <span className="text-[11px] font-semibold text-stone-500 uppercase px-1.5 flex items-center gap-1 hidden md:flex">
        <Palette className="w-3 h-3 text-stone-500" />
        Kleur:
      </span>

      <div className="flex items-center gap-1">
        {COLOR_THEMES.map((theme) => {
          const isSelected = currentTheme === theme.id;
          return (
            <button
              key={theme.id}
              onClick={() => onSelectTheme(theme.id)}
              className={`group relative flex items-center justify-center w-7 h-7 rounded-lg transition-all ${
                isSelected
                  ? 'ring-2 ring-stone-900 ring-offset-1 scale-105 shadow-2xs'
                  : 'opacity-75 hover:opacity-100 hover:scale-105'
              }`}
              style={{ backgroundColor: theme.previewColor }}
              title={`${theme.name}: ${theme.description}`}
              aria-label={`Selecteer thema ${theme.name}`}
            >
              {isSelected && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
            </button>
          );
        })}
      </div>
    </div>
  );
};
