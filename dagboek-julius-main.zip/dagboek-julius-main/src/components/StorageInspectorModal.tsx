import React, { useState, useEffect } from 'react';
import { X, HardDrive, ShieldCheck, AlertCircle, Copy, Check, Terminal, ExternalLink } from 'lucide-react';
import { getStorageDiagnostics, STORAGE_KEY } from '../utils/storage';

interface StorageInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StorageInspectorModal: React.FC<StorageInspectorModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [diagnostics, setDiagnostics] = useState(() => getStorageDiagnostics());

  useEffect(() => {
    if (isOpen) {
      setDiagnostics(getStorageDiagnostics());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(diagnostics.rawJson);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="relative w-full max-w-3xl bg-white border border-stone-200 rounded-3xl shadow-xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-stone-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <HardDrive className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-stone-900">
                Waar staat je data? (Vragen 4 & 5)
              </h2>
              <p className="text-xs text-stone-500">
                Uitleg over de opslaglocatie, voordelen en nadelen
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-stone-700">
          {/* Antwoord op vraag 4: Waar staat je data? */}
          <div className="bg-amber-50/60 border border-amber-200/80 rounded-2xl p-4 sm:p-5 space-y-2">
            <span className="text-xs font-bold text-amber-900 uppercase tracking-wider">
              Vraag 4: Waar staat je data precies?
            </span>
            <p className="text-sm font-semibold text-stone-900">
              Je data staat 100% lokaal op je eigen apparaat in de browser via <code className="bg-amber-100/80 px-1.5 py-0.5 rounded text-xs font-mono text-amber-900">window.localStorage</code>.
            </p>
            <p className="text-xs text-stone-600 leading-relaxed">
              De browser reserveert een geïsoleerde kluis voor deze webapplicatie. De sleutelnaam waar al je dagboeknotities in staan is:
            </p>
            <div className="bg-stone-900 text-amber-300 font-mono text-xs px-3 py-2 rounded-xl flex items-center justify-between">
              <span>Key: <strong>{STORAGE_KEY}</strong></span>
              <span className="text-stone-400">{diagnostics.entryCount} notities ({diagnostics.sizeBytes} bytes)</span>
            </div>
          </div>

          {/* Stappenplan om de data zelf te vinden in de browser */}
          <div className="border border-stone-200 rounded-2xl p-4 sm:p-5 space-y-3">
            <h3 className="text-xs uppercase tracking-wider font-bold text-stone-500 flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-stone-700" />
              Zo kun je de data zelf vinden in je browser (Stap-voor-stap):
            </h3>

            <ol className="list-decimal list-inside space-y-2 text-xs text-stone-700">
              <li>
                <strong className="text-stone-900">Open Ontwikkelaarstools:</strong> Druk op <kbd className="px-1.5 py-0.5 bg-stone-100 border border-stone-300 rounded text-[11px] font-mono">F12</kbd> (of op Mac: <kbd className="px-1.5 py-0.5 bg-stone-100 border border-stone-300 rounded text-[11px] font-mono">Cmd + Option + I</kbd>), of klik met de rechtermuisknop op de pagina en kies <em>Inspecteren</em>.
              </li>
              <li>
                <strong className="text-stone-900">Ga naar het tabblad &quot;Application&quot;</strong> (in Nederlandse Chrome heet dit <em>Toepassing</em> of <em>Opslag</em>).
              </li>
              <li>
                <strong className="text-stone-900">Klap links &quot;Local Storage&quot; open:</strong> Klik op de URL van deze app.
              </li>
              <li>
                <strong className="text-stone-900">Zoek de sleutel:</strong> Klik op de rij <code className="bg-stone-100 px-1 rounded font-mono">{STORAGE_KEY}</code>. Rechts zie je dan exact alle JSON-tekst van jouw dagboek!
              </li>
            </ol>
          </div>

          {/* Live inspectie van de werkelijke data */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
                Live inspectie van jouw browser LocalStorage ({STORAGE_KEY}):
              </span>
              <button
                onClick={handleCopy}
                className="text-xs text-stone-600 hover:text-stone-900 flex items-center gap-1 px-2.5 py-1 bg-stone-100 rounded-lg hover:bg-stone-200 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Gekopieerd' : 'Kopieer ruwe JSON'}</span>
              </button>
            </div>
            <pre className="bg-stone-900 text-stone-200 text-xs p-3.5 rounded-2xl overflow-x-auto max-h-40 font-mono leading-relaxed select-all">
              {JSON.stringify(JSON.parse(diagnostics.rawJson || '[]'), null, 2)}
            </pre>
          </div>

          {/* Vraag 5: Wat is het voordeel en wat is het nadeel? */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            {/* Voordelen */}
            <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-2">
              <div className="flex items-center gap-1.5 text-emerald-900 font-bold text-xs uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>Voordelen van LocalStorage:</span>
              </div>
              <ul className="list-disc list-inside space-y-1.5 text-xs text-emerald-950">
                <li><strong>100% Privacy:</strong> Je diepste gedachten staan niet op een externe server van een techbedrijf.</li>
                <li><strong>Werkt altijd offline:</strong> Geen internetverbinding nodig om te schrijven of herinneringen te lezen.</li>
                <li><strong>Geen gedoe met accounts:</strong> Geen wachtwoorden, verificatiemails of cookies.</li>
                <li><strong>Razendsnel:</strong> Opslaan gebeurt instant (0 ms netwerklatentie).</li>
              </ul>
            </div>

            {/* Nadelen */}
            <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2">
              <div className="flex items-center gap-1.5 text-amber-900 font-bold text-xs uppercase tracking-wider">
                <AlertCircle className="w-4 h-4 text-amber-700" />
                <span>Nadelen van LocalStorage:</span>
              </div>
              <ul className="list-disc list-inside space-y-1.5 text-xs text-amber-950">
                <li><strong>Niet automatisch gesynchroniseerd:</strong> Schrijf je op je laptop, dan staat het niet automatisch op je mobiel (je moet een export/import doen).</li>
                <li><strong>Kans op dataverlies bij opschonen:</strong> Als je je browsergeschiedenis/cookies agressief wist, kan het dagboek verdwijnen (vandaar de Excel- en JSON downloadknoppen!).</li>
                <li><strong>Opslaglimiet:</strong> Ongeveer 5 tot 10 MB per domein (ruim voldoende voor tekst, maar niet voor grote foto&apos;s/video&apos;s).</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-stone-50 border-t border-stone-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-900 bg-amber-400 hover:bg-amber-300 rounded-xl transition-colors cursor-pointer"
          >
            Sluiten
          </button>
        </div>
      </div>
    </div>
  );
};
