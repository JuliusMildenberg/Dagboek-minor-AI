import React, { useRef, useState } from 'react';
import { DiaryEntry, MOODS } from '../types/diary';
import { exportEntriesAsJson, exportEntriesAsExcelCsv, importEntriesFromJson } from '../utils/storage';
import { Download, Upload, Printer, Database, Check, AlertTriangle, ShieldCheck, FileSpreadsheet, HardDrive, Star } from 'lucide-react';

interface BackupViewProps {
  entries: DiaryEntry[];
  onRefreshEntries: () => void;
  onOpenStorageInspector: () => void;
}

export const BackupView: React.FC<BackupViewProps> = ({
  entries,
  onRefreshEntries,
  onOpenStorageInspector,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [errorStatus, setErrorStatus] = useState<string | null>(null);

  // Statistics calculation
  const totalEntries = entries.length;
  const favoriteCount = entries.filter((e) => e.isFavorite).length;
  const moodCounts = entries.reduce<Record<string, number>>((acc, curr) => {
    acc[curr.mood] = (acc[curr.mood] || 0) + 1;
    return acc;
  }, {});

  let topMood: string | null = null;
  let maxMoodCount = 0;
  Object.entries(moodCounts).forEach(([moodId, count]) => {
    if (count > maxMoodCount) {
      maxMoodCount = count;
      topMood = moodId;
    }
  });
  const topMoodObj = topMood ? MOODS.find((m) => m.id === topMood) : null;

  const handleExportJson = () => {
    exportEntriesAsJson();
  };

  const handleExportExcel = () => {
    exportEntriesAsExcelCsv();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = importEntriesFromJson(content);
      if (res.success) {
        setImportStatus(`Succesvol geïmporteerd! Er zijn ${res.count} nieuwe notities toegevoegd.`);
        setErrorStatus(null);
        onRefreshEntries();
      } else {
        setErrorStatus(res.error || 'Er is een fout opgetreden bij het importeren.');
        setImportStatus(null);
      }
      // Reset input
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsText(file);
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-2xl sm:text-3xl font-serif text-stone-900 tracking-tight">
            Overzicht, Back-up & Data
          </h2>
          <p className="text-sm text-stone-600 mt-1">
            Beheer je gegevens, exporteer naar Excel en bekijk waar je data bewaard staat.
          </p>
        </div>

        {/* Vraag 4 & 5 knop */}
        <button
          onClick={onOpenStorageInspector}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-stone-800 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-xl transition-colors cursor-pointer"
        >
          <HardDrive className="w-3.5 h-3.5 text-amber-700" />
          <span>Waar staat mijn data?</span>
        </button>
      </div>

      {importStatus && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3">
          <Check className="w-5 h-5 text-emerald-600 shrink-0" />
          <p className="text-sm font-medium">{importStatus}</p>
        </div>
      )}

      {errorStatus && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
          <p className="text-sm font-medium">{errorStatus}</p>
        </div>
      )}

      {/* Statistieken widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-stone-200/80 rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-stone-500 uppercase tracking-wider font-semibold">
            Dagen gereflecteerd
          </span>
          <div className="flex items-baseline justify-between mt-1">
            <p className="text-3xl font-serif font-bold text-stone-900 tabular-nums">
              {totalEntries}
            </p>
            {favoriteCount > 0 && (
              <span className="flex items-center gap-1 text-xs text-amber-600 font-medium">
                <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                {favoriteCount} favoriet
              </span>
            )}
          </div>
          <p className="text-xs text-stone-500 mt-1">
            {totalEntries === 0 ? 'Nog geen inzendingen' : 'Dagboeknotities bewaard'}
          </p>
        </div>

        <div className="bg-white border border-stone-200/80 rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-stone-500 uppercase tracking-wider font-semibold">
            Meest voorkomende stemming
          </span>
          <div className="flex items-center gap-2 mt-1">
            {topMoodObj ? (
              <>
                <span className="text-2xl">{topMoodObj.emoji}</span>
                <span className="text-base font-semibold text-stone-800">
                  {topMoodObj.label}
                </span>
                <span className="text-xs text-stone-400">
                  ({maxMoodCount}x)
                </span>
              </>
            ) : (
              <span className="text-sm text-stone-400 mt-1">Nog geen data</span>
            )}
          </div>
          <p className="text-xs text-stone-500 mt-1">Gevoel van je dagen</p>
        </div>

        <div className="bg-white border border-stone-200/80 rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-stone-500 uppercase tracking-wider font-semibold">
            Privacy & Opslag
          </span>
          <div className="flex items-center gap-1.5 text-emerald-700 font-semibold text-sm mt-1">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>100% Lokaal (LocalStorage)</span>
          </div>
          <button
            onClick={onOpenStorageInspector}
            className="text-xs text-amber-700 hover:text-amber-800 underline mt-1 text-left cursor-pointer"
          >
            Bekijk voor- & nadelen
          </button>
        </div>
      </div>

      {/* Export Opties inclusief Excel (Vraag 6) */}
      <div className="bg-white border border-stone-200/80 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-stone-600" />
            <h3 className="text-base font-semibold text-stone-900">
              Exporteren & Downloaden (Vraag 6)
            </h3>
          </div>
          <span className="text-xs text-stone-500">Kies gewenst formaat</span>
        </div>

        <p className="text-sm text-stone-600">
          Download al je dagboeknotities naar je computer. Je kunt kiezen voor een Microsoft Excel spreadsheet, een JSON-reservekopie of een nette printweergave.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          {/* Vraag 6: Excel download knop */}
          <button
            onClick={handleExportExcel}
            className="flex flex-col items-center justify-center p-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-center shadow-xs transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-1.5 font-semibold text-sm mb-0.5">
              <FileSpreadsheet className="w-4 h-4 group-hover:scale-110 transition-transform" />
              <span>Download naar Excel</span>
            </div>
            <span className="text-[11px] text-emerald-100">.csv met alle 4 de vragen</span>
          </button>

          {/* JSON Exporteren knop */}
          <button
            onClick={handleExportJson}
            className="flex flex-col items-center justify-center p-3.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-center shadow-xs transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-1.5 font-semibold text-sm mb-0.5">
              <Download className="w-4 h-4 group-hover:scale-110 transition-transform" />
              <span>Exporteer JSON</span>
            </div>
            <span className="text-[11px] text-stone-300">Volledige reservekopie</span>
          </button>

          {/* Printen / PDF knop */}
          <button
            onClick={() => window.print()}
            className="flex flex-col items-center justify-center p-3.5 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-center transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-1.5 font-semibold text-sm mb-0.5">
              <Printer className="w-4 h-4 text-stone-600 group-hover:scale-110 transition-transform" />
              <span>Afdrukken / PDF</span>
            </div>
            <span className="text-[11px] text-stone-500">Papier of PDF archief</span>
          </button>
        </div>

        {/* Importeren */}
        <div className="pt-3 border-t border-stone-100 flex items-center justify-between flex-wrap gap-2 text-xs">
          <span className="text-stone-500">
            Heb je al een eerder geëxporteerd JSON-bestand?
          </span>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-lg text-stone-700 font-medium cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 text-stone-500" />
            <span>Importeer JSON bestand</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".json"
            className="hidden"
          />
        </div>
      </div>
    </div>
  );
};
