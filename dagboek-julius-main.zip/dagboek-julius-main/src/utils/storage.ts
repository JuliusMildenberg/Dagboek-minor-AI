import { DiaryEntry, ColorThemeId } from '../types/diary';

export const STORAGE_KEY = 'digitaal_dagboekje_entries_v1';
export const THEME_KEY = 'digitaal_dagboekje_theme_v1';

// Formatteert een datum naar vriendelijk Nederlands (bijv. "Donderdag 24 september 2026")
export function formatDateDutch(dateString: string): string {
  try {
    const parts = dateString.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      const date = new Date(year, month, day);
      return new Intl.DateTimeFormat('nl-NL', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      }).format(date);
    }
  } catch {
    // fallback
  }
  return dateString;
}

export function formatShortDateDutch(dateString: string): string {
  try {
    const parts = dateString.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      const date = new Date(year, month, day);
      return new Intl.DateTimeFormat('nl-NL', {
        day: 'numeric',
        month: 'short',
      }).format(date);
    }
  } catch {
    // fallback
  }
  return dateString;
}

export function getTodayString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

const DEFAULT_SAMPLE_ENTRIES: DiaryEntry[] = [
  {
    id: 'sample-1',
    date: getTodayString(),
    createdAt: new Date().toISOString(),
    mood: 'goed',
    isFavorite: true,
    question1: 'De ochtendzon tijdens het ontbijt en een productieve start van de dag.',
    question2: 'Mijn takenlijstje van vanochtend voor de lunch al helemaal af kunnen vinken.',
    question3: 'Even te lang doorgewerkt zonder pauze, morgen bewust rond 12:30 even een blokje om.',
    question4: "Focus houden op één taak tegelijk en 's avonds ontspannen met een goed boek.",
  },
];

export function getStoredEntries(): DiaryEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_SAMPLE_ENTRIES));
      return DEFAULT_SAMPLE_ENTRIES;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Error loading diary entries:', err);
    return [];
  }
}

export function saveEntry(entry: Omit<DiaryEntry, 'id' | 'createdAt'>, existingId?: string): DiaryEntry {
  const current = getStoredEntries();
  
  if (existingId) {
    const updated = current.map((item) => {
      if (item.id === existingId) {
        return {
          ...item,
          ...entry,
          updatedAt: new Date().toISOString(),
        };
      }
      return item;
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return updated.find((e) => e.id === existingId)!;
  }

  const newEntry: DiaryEntry = {
    ...entry,
    id: 'dagboek-' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
    createdAt: new Date().toISOString(),
  };

  const updated = [newEntry, ...current];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return newEntry;
}

export function toggleFavoriteEntry(id: string): DiaryEntry | null {
  const current = getStoredEntries();
  let updatedEntry: DiaryEntry | null = null;
  const updated = current.map((item) => {
    if (item.id === id) {
      updatedEntry = { ...item, isFavorite: !item.isFavorite };
      return updatedEntry;
    }
    return item;
  });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return updatedEntry;
}

export function deleteStoredEntry(id: string): void {
  const current = getStoredEntries();
  const updated = current.filter((item) => item.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
}

export function exportEntriesAsJson(): void {
  const entries = getStoredEntries();
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(entries, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `digitaal-dagboek-${getTodayString()}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

/**
 * Exporteert alle dagboekregels als een Microsoft Excel CSV bestand
 * Inclusief UTF-8 BOM (\uFEFF) en puntkomma (;) scheidingsteken zodat Excel in Europa/NL
 * de kolommen automatisch netjes splitst en speciale tekens (ë, é, etc.) correct toont.
 */
export function exportEntriesAsExcelCsv(): void {
  const entries = getStoredEntries();
  
  // Headers conform de 4 vragen en metadata
  const headers = [
    'ID',
    'Datum',
    'Datum (Tekst)',
    'Stemming',
    'Vraag 1: Waar ben je dankbaar voor?',
    'Vraag 2: Hoogtepunt van de dag',
    'Vraag 3: Uitdaging & Leermoment',
    'Vraag 4: Intentie voor morgen',
    'Favoriet',
    'Aangemaakt op',
  ];

  // Helper om CSV velden veilig te quoten
  const escapeCsv = (str: string | undefined | null) => {
    if (str === undefined || str === null) return '""';
    const text = String(str).replace(/"/g, '""').replace(/\r\n|\r|\n/g, ' ');
    return `"${text}"`;
  };

  const rows = entries.map((entry) => [
    escapeCsv(entry.id),
    escapeCsv(entry.date),
    escapeCsv(formatDateDutch(entry.date)),
    escapeCsv(entry.mood),
    escapeCsv(entry.question1),
    escapeCsv(entry.question2),
    escapeCsv(entry.question3),
    escapeCsv(entry.question4),
    escapeCsv(entry.isFavorite ? 'Ja' : 'Nee'),
    escapeCsv(new Date(entry.createdAt).toLocaleString('nl-NL')),
  ]);

  // Semicolon separator is standard for Dutch/European Excel
  const csvContent = [headers.join(';'), ...rows.map((r) => r.join(';'))].join('\r\n');

  // Add UTF-8 BOM so Excel opens it with correct encoding
  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', url);
  downloadAnchor.setAttribute('download', `dagboek-export-${getTodayString()}.csv`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
  URL.revokeObjectURL(url);
}

export function importEntriesFromJson(jsonText: string): { success: boolean; count: number; error?: string } {
  try {
    const parsed = JSON.parse(jsonText);
    if (!Array.isArray(parsed)) {
      return { success: false, count: 0, error: 'Het bestand bevat geen geldige lijst met dagboeknotities.' };
    }
    
    // Validate basic structure
    const valid = parsed.filter(
      (item) => item && typeof item.date === 'string' && typeof item.question1 === 'string'
    );

    if (valid.length === 0) {
      return { success: false, count: 0, error: 'Geen herkenbare dagboeknotities gevonden.' };
    }

    const current = getStoredEntries();
    const existingIds = new Set(current.map((e) => e.id));
    const combined = [...current];

    let newCount = 0;
    for (const item of valid) {
      if (!existingIds.has(item.id)) {
        combined.push(item);
        existingIds.add(item.id);
        newCount++;
      }
    }

    // Sorteer op datum aflopend
    combined.sort((a, b) => b.date.localeCompare(a.date));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(combined));

    return { success: true, count: newCount };
  } catch (err: any) {
    return { success: false, count: 0, error: err?.message || 'Fout bij het importeren.' };
  }
}

// Storage Inspectie info voor opdracht punt 4 & 5
export function getStorageDiagnostics() {
  const rawData = localStorage.getItem(STORAGE_KEY) || '[]';
  const sizeBytes = new Blob([rawData]).size;
  const entries = getStoredEntries();
  return {
    key: STORAGE_KEY,
    rawJson: rawData,
    sizeBytes,
    entryCount: entries.length,
    storageType: 'Window LocalStorage (HTML5 Web Storage API)',
  };
}

// Color theme storage
export function getStoredTheme(): ColorThemeId {
  try {
    const theme = localStorage.getItem(THEME_KEY) as ColorThemeId;
    if (theme && ['warm-paper', 'sage', 'sunset', 'night', 'ocean'].includes(theme)) {
      return theme;
    }
  } catch {
    // fallback
  }
  return 'warm-paper';
}

export function saveStoredTheme(theme: ColorThemeId): void {
  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch (e) {
    console.error('Error saving theme:', e);
  }
}
